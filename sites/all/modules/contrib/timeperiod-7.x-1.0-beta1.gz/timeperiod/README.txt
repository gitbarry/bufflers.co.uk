
--------------------------------------------------------------------------------
                      Time period widget & formatter
--------------------------------------------------------------------------------

A simple time period widget and formatter for time periods stored in seconds.

Time periods can be entered using multiple units, whereas the module allows
inputing days, hours, minutes and seconds. Each unit can be enabled separately
and the maximum value and step size can be configured.


Dependencies
------------

 * Field API (core)

Usage
-----

 * Enable the module.
 * Create a field of type integer and select a time period widget and or
   formatter.
   

Maintainers:
 * Heimo Reiter (heimo) heimo@doloops.net
 * Wolfgang Ziegler (fago), nuppla@zites.net
 
 
 Initial development has been sponsored by doloops.net.